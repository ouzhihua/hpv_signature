#' Use SNP sites to identify corresponding lineages/sublineages by matching the SNP datasets
#' @name snp_matcher
#' @description  Use marker SNP to identify phylogeny groups;
#' @param alignment sequence alignment in fasta format with a ref exactly the same as that of the database;
#' @param snp_info SNP and plylogeny group information in csv format, see example files;
#' @param out_dir output directory, defult is current working directory;
#' @return csv files showing SNP information and a fasta file containing the reference sequence;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 12 August 2019. Contact:ouzhihua@genomics.cn


snp_matcher <- function(alignment, snp_info, out_dir=getwd()){

 # rm(list=ls())
  #setwd("~/Documents/BGI/manuscript/data/snp_matcher")
  #snp_info="../snp_hierarchy/hpv58_adjusted_sublineage_hierarchy_hierarchy_snp_ratio_exclusive.csv"
   #           alignment="../bgiseq/HPV58_repseq_with_bgiseq.fasta"
    #          out_dir=getwd()
  library(Biostrings)
  library(dplyr)
  library(tidyr)

  filename <- paste0(out_dir, "/", gsub(".fasta", "", gsub("^.*/", "", alignment)))

  # input sequences
  fas <- readDNAStringSet(alignment)
  name = names(fas)
  seq = toupper(paste(fas))
  length = width(paste(fas))
  df <- data.frame(name, seq, length)


  # check if sequences are aligned
  if (length(unique(df$length))>1){
    print("Oops~ Sequences are not aligned!")
  }else{
    print("Nice! Sequences are properly aligned~")
  }

  # read lineage information and check if ref is present
  clade_info <- read.csv(snp_info, header=T, na.strings=c("", NA), stringsAsFactors = F) %>%
    arrange(desc(Nucleotide_ratio)) %>%
    distinct(real_position, lineage, .keep_all=T) %>%
    select(ref, real_position, Nucleotide, lineage)

  ref <- unique(clade_info$ref)

  # get alignment length
  ali_len <- df$length[df$name==ref]

  if(length(ali_len)==0){
    print("reference sequence not found!")
  }


  # match to real position
  position_match <- df %>% filter(name==ref) %>%
    select(name) %>% mutate(ali_position=NA, real_position=NA)
  position_match[2:ali_len, ] <- NA
  position_match$name <- ref
  refseq <- df %>% filter(name==ref)
  refseq <- refseq$seq[1]
  r <- 0

  for (i in 1:ali_len){
    position_match$ali_position[i] <- i
    if(substr(refseq, i, i) != "-"){
      r <- r+1
      position_match$real_position[i] <- r
    }else{
      position_match$real_position[i] <- paste0(r,"+gap")
    }
  }
  colnames(position_match)[1] <- "ref"

  #output ref snp info
  ref_out <- clade_info %>%
    spread(real_position, Nucleotide)
  ref_out$lineage <- gsub("_n.*$", "", ref_out$lineage)
  write.csv(ref_out, paste0(filename, "_snp_database.csv"), row.names = F, na="")



  #--------------------- function to get snp
  get_snp <- function(data){
    df_clade <- data
    # select informative sites
    snp_position <- position_match %>% filter(real_position %in% unique(df_clade$real_position))

    seq_snp <- data.frame(name=NA, real_position=NA, ali_position=NA, Nucleotide=NA)

    df <- df %>% arrange(name)
    for (i in 1:length(df$name)){
      seq_snp.i <- snp_position %>% mutate(name=df$name[i], Nucleotide=NA) %>% select(-ref)
      seq.i <- df$seq[i]

      for (j in 1:length(snp_position$ali_position)){
        seq_snp.i[j,"Nucleotide"] <- substr(seq.i, snp_position$ali_position[j], snp_position$ali_position[j])
      }
      seq_snp <- rbind(seq_snp, seq_snp.i)
    }
    seq_snp <- seq_snp %>% na.omit()

    # get lineage-specific snp and check lineage
    seq_snp$real_position <- as.numeric(seq_snp$real_position)
    df_clade$real_position <- as.numeric(df_clade$real_position)

    seq_snp <- left_join(seq_snp, df_clade, by=c("real_position", "Nucleotide")) %>%
      mutate(ref=unique(df_clade$ref))
    return(seq_snp)
  }

  sum_snp <- function(data){
    snp_info <- data
    seq_snp_sum <- snp_info %>% group_by(name, lineage) %>% summarise(n=n())
    seq_snp_sum <- as.data.frame(seq_snp_sum) %>% filter(!is.na(lineage))
    seq_snp_sum$mylevel <- str_split_fixed(seq_snp_sum$lineage, "_", 3)[,2]
    seq_snp_sum$level_lineage <- str_split_fixed(seq_snp_sum$lineage, "_", 4)[,3]
    seq_snp_sum$level_lineage <- gsub("_.*$", "", seq_snp_sum$level_lineage)
    return(seq_snp_sum)
  }

  assign_clade <- function(data){
    seq_snp_sum <- data
    seq_snp_wide <- seq_snp_sum %>% arrange(desc(n)) %>%
      distinct(name, mylevel, .keep_all=T) %>%
      select(-lineage, -n) %>%
      spread(mylevel, level_lineage) %>%
      mutate(snp_lineage=NA)


    n_levels <- unique(seq_snp_sum$mylevel)
    if (length(n_levels)>1){
      for (i in 1:length(seq_snp_wide$name)){
        j=1
        while (j < length(n_levels)){
          if(!is.na(seq_snp_wide[i, n_levels[j]]) & !is.na(seq_snp_wide[i, n_levels[j+1]]) & grepl(seq_snp_wide[i, n_levels[j+1]], seq_snp_wide[i, n_levels[j]])==1){
            seq_snp_wide[i, "snp_lineage"] <- seq_snp_wide[i, n_levels[j+1]]
            j=j+1

          }else{
            seq_snp_wide[i, "snp_lineage"] <- seq_snp_wide[i, n_levels[j]]
            break
          }
        }
      }
    }else{
      seq_snp_wide$snp_lineage <- seq_snp_wide[,n_levels]
    }

    seq_snp_wide <- seq_snp_wide %>% select(name, snp_lineage)
    return(seq_snp_wide)
   }

  # get snp for lineage
  df_lineage <- clade_info %>% filter(grepl("^lineage_", lineage))
  lin_snp <- get_snp(data=df_lineage) %>% distinct()
  lin_snp_sum <- sum_snp(lin_snp)
  lin_snp_clade <- assign_clade(lin_snp_sum)

  # get snp for sublineage
  df_sublineage <- clade_info %>% filter(grepl("^sublineage", lineage))

  if (length(df_sublineage$ref)>0){
    sublin_snp <- get_snp(data=df_sublineage)
    sublin_snp_sum <- sum_snp(sublin_snp)

    sublin_snp_sum_out <- data.frame()

    for (i in 1:length(lin_snp_clade$name)){
      seq <- lin_snp_clade$name[i]
      sublin_snp_sum.i <- sublin_snp_sum %>% filter(name==seq & grepl(lin_snp_clade$snp_lineage[i], level_lineage))
      sublin_snp_sum_out <- rbind(sublin_snp_sum_out, sublin_snp_sum.i)
    }

    sublin_snp_sum_out <- sublin_snp_sum_out %>% distinct()

    sublin_snp_clade <- assign_clade(sublin_snp_sum_out)
    colnames(sublin_snp_clade)[2] <- "snp_sublineage"
    clade_out <- left_join(lin_snp_clade, sublin_snp_clade) %>%
      mutate(snp_sublineage=ifelse(is.na(snp_sublineage), snp_lineage, snp_sublineage))


    sublin_snp_select <- get_snp(data=df_sublineage)
    sublin_snp_select <- semi_join(sublin_snp_select, sublin_snp_sum_out, by=c("name","lineage"))

    snp_out <- rbind(lin_snp, sublin_snp_select) %>%
      select(ref, real_position, name, Nucleotide) %>%
      spread(real_position, Nucleotide)
    output <- left_join(clade_out, snp_out, by="name")
    write.csv(output, paste0(filename, "_snp_sublineage.csv"), row.names = F, na="")

  }else{
       seq_snp_out <- lin_snp %>% select(ref, real_position, name, Nucleotide) %>%
        spread(real_position, Nucleotide)
       output <- left_join(seq_snp_wide, seq_snp_out, by="name")
       write.csv(output, paste0(filename, "_snp_lineage_only.csv"), row.names = F, na="")
  }
}











