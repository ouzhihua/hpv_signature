#' Clean genbank infomation file for HPV sequences.
#' @name gb_parse
#' @param gbfile A genbank file with suffix ".gb";
#' @param ref_info A csv file containg reference seq information;
#' @param ref_accession Column in ref_info.csv containing reference accession number;
#' @param ref_group Column in ref_info.csv containing reference phylogeny group information, such as sublineage;
#' @return Files containg cleaned data and processing logs.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 25 July 2019. Contact:ouzhihua@genomics.cn

#gbfile <- "test.gb"

gb_parse <- function(gbfile, ref_info=NA, ref_accession=NA, ref_group=NA){
  library(dplyr)
  library(stringr)

  df <- readLines(gbfile)


  # generate line index for each accession
  dat <- data.frame("No" = 1:length(grep('^LOCUS', df))) %>%
    mutate(locus_index = grep('^LOCUS', df),
           sep_index = grep('^//', df))


  for (i in 1:length(dat$No)) {
    df.i <- df[dat$locus_index[i]:dat$sep_index[i]]
    dat[i, "accession"] <- str_split_fixed(str_split_fixed(as.character(df.i[grep('^ACCESSION', df.i)]), " ", 4)[1,4], " ", 2)[,1]
    dat[i, "gi"] <- str_split_fixed(as.character(df.i[grep('^VERSION', df.i)]), "GI:", 2)[1,2]
    dat[i, "length"] <- str_split_fixed(as.character(df.i[grep('source', df.i)]), "\\.", 3)[1,3]
    dat[i, "definition"] <- str_split_fixed(as.character(df.i[grep('^DEFINITION', df.i)]), "  ", 2)[1,2]

    if(length(df.i[grep('^SOURCE', df.i)])>0){
      dat[i, "hpv_type1"] <- gsub(" ", "", str_split_fixed(as.character(df.i[grep('^SOURCE', df.i)]), "type ", 2)[1,2])
    }



    # create function to retrieve strain info
    get_info <- function(data, myinfo){
      marker <- paste0('/', myinfo, '=')
      if(length(data[grep(marker, data)])>0){
        out <- gsub('"', "", str_split_fixed(as.character(data[grep(marker, data)]), "=", 2)[1,2])
      } else {
        out <- NA
      }
      return(out)
    }

    # get strain info
    info <- c("collection_date", "country", "isolate", "host", "organism", "note", "mol_type", "db_xref")

    for (j in 1:length(info)){
      dat[i, info[j]] <- get_info(data=df.i, myinfo=info[j])
    }


    # create function to retrieve cds of each gene
    get_cds <- function(data, mygene, mylabel){
      gene = paste0("/gene=", '"', mylabel, '"')
      product = paste0("/product=", '"', mylabel, '"')
      product_p = paste0("/product=", '"', mylabel, ' protein"')

      if(length(data[grepl(gene, data)])>0){
        cds <- str_split_fixed(as.character(data[(grep(gene, data)-1)][1]), "gene", 2)[1,2]
      } else if (length(data[grepl(product, data)])>0){
        cds <- str_split_fixed(as.character(data[grep(product, data)-2][1]), "CDS", 2)[1,2]
        if (cds==""){
          cds <- str_split_fixed(as.character(data[grep(product, data)-3][1]), "CDS", 2)[1,2]
        }
      } else if (length(data[grepl(product_p, data)])>0){
        cds <- str_split_fixed(as.character(data[grep(product_p, data)-2][1]), "CDS", 2)[1,2]
      } else{
        cds <- NA
      }
      return(gsub("[>< ]", "", cds))
    }

    # use function to get cds of genes
    genes <- c("E1", "E2", "E4", "E5", "E6", "E7", "L1", "L2")
   # m=1
    for (m in 1:length(genes)){
      dat[i, genes[m]] <- get_cds(data=df.i, mygene=genes[m], mylabel=genes[m])
    }

  }


  # extract lineage info
  sort(unique(dat$note))
  dat$lineage <- NA
  for (i in 1:length(dat$accession)){
    if (grepl("lineage", dat$note[i])==1){
      dat$lineage[i] <- gsub("lineage ", "", dat$note[i])
    } else if (grepl("genotype", dat$note[i])==1){
      dat$lineage[i] <- gsub("genotype: ", "", dat$note[i])
    }else{
      dat$lineage[i] <- NA
    }
  }

  # get hpv type based taxon id
  txid_type <- system.file("extdata/hpv_type_and_txid.csv", package = "evhpv")
  td <- read.csv(txid_type) %>%
    filter(!db_xref %in% c("taxon:2093789", "taxon:10566")) %>%
    select(db_xref, txid_type)
  colnames(td)
  dat <- left_join(dat, td, by="db_xref")
  dat <- dat %>% mutate(hpv_type=ifelse(!is.na(as.character(txid_type)), as.character(txid_type),
                                         ifelse(!is.na(as.character(hpv_type1)), as.character(hpv_type1), NA)))


  # filter out patent/mosaic/cellular/junctional/lab strains
  exlist <- c("patent", "mosaic", "cellular", "junctional", "lab", "integrat", "jp ", "mutant")
  exdat <- dat[0,]

  for (x in 1:length(exlist)){
    dfx <- dat %>% filter(grepl(exlist[x], tolower(definition)))

    if(length(dfx$No)>0){
      exdat <- rbind(exdat, dfx)
    }
  }


  # exclude patent/mosaic/cellular/junctional/lab strains
  dat <- anti_join(dat, exdat, by="accession")


  # clean collection place and year for rename fasta sequences
  dat$collection_year <- NA
  for (l in 1:length(dat$accession)){
    if(!is.na(dat$collection_date[l])){
      dat$collection_year[l] <- substr(dat$collection_date[l], nchar(dat$collection_date[l])-3, nchar(dat$collection_date[l]))
    }else{
      dat$collection_year[l] <- "na"
    }
  }
  dat <- dat %>% mutate(collection_year = ifelse(grepl("-", collection_year), NA, collection_year))

  dat$place <- NA
  for (l in 1:length(dat$accession)){
    if(!is.na(dat$country[l])){
      dat$place[l] <- gsub(" ", "_", str_split_fixed(dat$country[l], ":", 2)[,1])
    }else{
      dat$place[l] <- "na"
    }
  }


  # create fasta sequence names
  if(!is.na(ref_info)){
    dref <- read.csv(ref_info, header=T, stringsAsFactors = F) %>% select(ref_accession, ref_group)
    colnames(dref) <- c("accession", "group_info")
    dat <- left_join(dat, dref, by="accession") %>% arrange(group_info)
    dat <- dat %>% mutate(fasname = ifelse(is.na(group_info),
                                           paste0(accession, "_", "HPV", hpv_type, "_", place, "_", collection_year),
                                           paste0(accession, "_", "HPV", hpv_type, "_", place, "_", collection_year, "_ref", group_info)))
  }else{
    dat <- dat %>% mutate(fasname = paste0(accession, "_", "HPV", hpv_type, "_", place, "_", collection_year))
  }

  # if lineage info available, include in the fasname
  dat <- dat %>% mutate(fasname=ifelse(!is.na(nchar(as.character(lineage))), paste0(as.character(fasname), "_ln" ,as.character(lineage)), as.character(fasname)))
  dat$fasname <- gsub("[(),; -]", "_", dat$fasname)
  dat$fasname <- gsub("[:]", "_", dat$fasname)
  dat$fasname <- gsub("___", "_", dat$fasname)
  dat$fasname <- gsub("__", "_", dat$fasname)
  dat$fasname <- gsub("_$", "", dat$fasname)
# output final information data
  dat <- dat %>% select(-(1:3))
  filename <- gsub(".gb$", "", gbfile)
  write.csv(dat, paste0(filename, "_info.csv"), row.names = F, quote=T, na="")

  write.csv(exdat[,-(1:3)], paste0(filename, "_info_excluded.csv"), row.names = F, quote=T, na="")

  output <- list(unique(dat$organism), unique(dat$hpv_type),
                 sort(unique(dat$collection_date)), sort(unique(dat$collection_year)),
                 sort(unique(dat$country)), sort(unique(dat$place)), unique(dat$mol_type))
  capture.output(output,
      file=paste0(filename, "_processlog.txt"))
}


