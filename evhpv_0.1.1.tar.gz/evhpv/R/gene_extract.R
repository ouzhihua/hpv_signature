#' extract coding regions for HPV genes.
#' @name gene_extract
#' @param alignment sequence alignment in fasta format;
#' @param pre prefix for output files;
#' @param hpvtype number indicating HPV type;
#' @param genes target gene to extract, can be one or more genes of the following: "E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1". Format of input: genes=c("E6", "E7");
#' @param index information file for HPV reference suequnces and the related gene coding regions, default is authored defined.
#' @return data frame of pairwide p-distance comparing against reference genomes.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 17 May 2019. Contact:ouzhihua@genomics.cn


#rm(list=ls())
#alignment <- "hpv16_ncbi_bgi_uptozhu20190401_trim_ndiff15.fasta"
#pre <- "hpv16"
#hpvtype <- "16"
#genes <- c("E6", "E7")
#index <- "HPV_CDS.txt"

gene_extract <- function(alignment, pre, hpvtype, genes, index=system.file("extdata/HPV_CDS.txt", package = "evhpv")){

  library(Biostrings, warn.conflicts = F)
  library(dplyr, warn.conflicts = F)
  library(stringr, warn.conflicts = F)

  dindex <- read.table(index, header=T, sep="\t")
  dgene <- dindex[grep(hpvtype, dindex$hpvtype),]
  acc <- as.character(dgene$accession)[1]

k=9
  for (k in 1:length(genes)){
    target <- genes[k]
    ds <- dgene %>% select(accession, target, full_length)
    colnames(ds)[2] <- "target"
    ref_len <- as.character(ds$full_length[1])
    g.start <- str_split_fixed(ds$target, "\\..",2)[,1]
    g.end <- str_split_fixed(ds$target, "\\..",2)[,2]

    fas <- readDNAStringSet(alignment)
    name = names(fas)
    ali_seq = toupper(paste(fas))
    length = width(fas)
    ali_length <- as.character(length[1])


    dfa <- data.frame(name, ali_seq)

    dref <- dfa[grep(acc, dfa$name),]
    ref_seq_len <- nchar(gsub("-", "", dref$ali_seq[1]))


    if (ref_len != ref_seq_len){
      print("real length of the reference in alignment should be the same as that in the index file, please check you files!")
    }else{
      data <- data.frame(ali_position=seq(1, ali_length, 1)) %>%
        mutate(real_position=NA)
      ref <- as.character(dref$ali_seq)


      j=0
      for (i in 1:ali_length){

        if (substr(ref, i, i) != "-"){
          j=j+1
          data$real_position[i]=j
        }else{
          data$real_position[i]=j
        }
      }

      s.start <- data %>% filter(real_position == g.start) %>% select(ali_position)
      s.start <- as.numeric(s.start)
      s.end <- data %>% filter(real_position == g.end) %>% select(ali_position)
      s.end <- as.numeric(s.end)

      if(target!="LCR"){
          dfa$target_seq <- substr(dfa$ali_seq, s.start, s.end)
      }else{
          dfa$target_seq <- paste0(substr(dfa$ali_seq, s.start, ali_length), substr(dfa$ali_seq, 1, s.end))
      }

      dfa <- dfa %>%
        mutate(fas = paste0(">", name, "\n", target_seq))
      write.table(dfa$fas, paste0(pre, "_", target, ".fasta"), sep="", col.name=F, row.names = F, quote=F)

      seq_check <- dfa %>% select(-ali_seq)
      seq_check$length <- nchar(gsub("-", "", seq_check$target_seq))
      seq_ok <- seq_check %>% filter(length >= max(seq_check$length)*0.7)
      seq_no <- seq_check %>% filter(length < max(seq_check$length)*0.7)

      if(length(seq_ok$name)<length(dfa$name)){
        write.table(seq_ok$fas, paste0(pre, "_", target, "_over0.7.fasta"), sep="", col.name=F, row.names = F, quote=F)
        write.table(seq_no$name, paste0(pre, "_", target, "_less0.7.csv"), sep="", col.name=F, row.names = F, quote=F)

      }

      print(paste0(length(seq_ok$name), " out of ", length(dfa$name), " ", pre, " have ", target, " of > 70% ORF length."))
    }

  }

}


#extract_gene(alignment="hpv16_ncbi_bgi_uptozhu20190401_trim_ndiff15.fasta", pre="hpv16", hpvtype="16", genes=c("E4", "E7", "E6", "E5"), index="HPV_CDS.txt")



