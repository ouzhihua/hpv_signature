#' check alignment quality before tree construction for HPV sequences.
#' @name check_alignment
#' @description preserve sequences with a length over a defined ratio of full length.
#' @param alignment sequence alignment in fasta format;
#' @param ratio required length ratio, eg, 0.7.
#' @return check results or adjusted alignment if applicable.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 17 May 2019. Contact:ouzhihua@genomics.cn

check_alignment <- function(alignment, ratio){
  library(Biostrings)
  library(dplyr)

  fas <- readDNAStringSet(alignment)
  name = names(fas)
  ali_seq = toupper(paste(fas))
  real_length = width(gsub("-", "", fas))
  dreal_length = data.frame(real_length)
  colnames(dreal_length) <- c("length")
  ali_length <- max(as.numeric(dreal_length$length))


  dfa <- data.frame(name, ali_seq, real_length) %>%
    mutate(selection=ifelse(real_length > ratio*ali_length, "yes", "no"))

  dfa_ex <- dfa %>% filter(selection == "no")
  print(paste0(alignment, ": exclude ", length(dfa_ex$name), " sequences"))

  dfa <- dfa %>% filter(selection=="yes") %>%
    mutate(fas = paste0(">", name, "\n", ali_seq))
  filename <- gsub(".fasta", "", gsub("^.*/", "", alignment))
  write.table(dfa$fas, paste0(filename, "_selected.fasta"), sep="", col.name=F, row.names = F, quote=F)

}


#check_alignment(alignment="hpv18.fasta", ratio=0.95)


