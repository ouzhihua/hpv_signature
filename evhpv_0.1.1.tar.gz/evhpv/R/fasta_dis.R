#' Calculate sequence distance matrix, gaps will be treated as missing data.
#' @name fasta_dis
#' @param alignment Aligned sequences in fasta format: xx.fasta;
#' @return A data frame of sequence pairwise distances;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 30 Oct 2019. Contact:ouzhihua@genomics.cn

fasta_dis <- function(alignment){
  # get pairwise distance for sequences
  library(seqinr)
  library(dplyr)
  library(stringr)

  align.fas <- read.alignment(alignment, format="fasta")
  dis <- as.matrix((dist.alignment(align.fas, matrix="identity"))^2) # the result is difference, which is equal to the p-distances calculated by Mega，pairwise deletion=TRUE
  dat <- data.frame(dis) %>% mutate(taxa=NA)

  for (i in 1:length(colnames(dat))-1) {
    dat$taxa[i] <- colnames(dat)[i]
  }
  row.names(dat) <- NULL

  dat$taxa <- gsub("\\.", "_", dat$taxa)
  colnames(dat) <- gsub("\\.", "_", colnames(dat))


  dis <- as.data.frame(select(dat, taxa, 1:(length(dat)-1)))
  write.csv(dis, paste0(gsub(".fasta", "", alignment), "_dis.csv"), row.names = F, quote=F)
}
