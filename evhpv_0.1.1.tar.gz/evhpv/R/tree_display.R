#' display tree with support values automatically
#' @name tree_display
#' @param treefile input a tree file with support values;
#' @param treetype three options: iqtree, raxmltree, megatree;
#' @param min_support minimum support value for display;
#' @param pre prefix for output files;
#' @param tree_sclae_width width for tree scale. Default: tree_scale_width=0.001;
#' @param adjust_node the node number to help restrict the tree width;
#' @param offset distance of clade label bar and text from clade;
#' @param filetype the output graphical type, "pdf" or "jpg", default is "pdf";
#' @param cutname cut BGI sequence name into shorter version. TRUE/FALSE, default=FALSE;
#' @param display_node whether show node number or not. TRUE/FALSE, default=TRUE;
#' @examples iqfile <- system.file("extdata/hpv18_iq.treefile", package = "evhpv")
#' @examples iqtree <- display_tree(treefile = iqfile, treetype = "iqtree", min_support=70, pre="hpv18_iqtree")
#' @examples megafile <- system.file("extdata/hpv18_mega.nwk", package = "evhpv")
#' @examples megatree <- display_tree(treefile = megafile, treetype = "megatree", min_support=70, pre="hpv18_megatree")
#' @examples raxmlfile <- system.file("extdata/RAxML_bipartitions_hpv18.nwk", package = "evhpv")
#' @examples raxmltree <- display_tree(treefile = raxmlfile, treetype = "raxmltree", min_support=70, pre="hpv18_raxmltree")
#' @return pdf and png files showing tree toplogy and support values, and the tree data for later processing.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 10 May 2019. Contact:ouzhihua@genomics.cn


tree_display <- function(treefile, treetype, min_support, pre, adjust_node, tree_scale_width=0.001, scale_x=NULL, scale_y=NULL, label=F, info, offset, cutname=FALSE, display_node=TRUE, filetype="pdf"){
  library(phangorn)
  library(dplyr)
  library(ggplot2)
  library(stringr)
  library(ggtree)
  library(readxl)
  
  tree <- read.tree(treefile)
  tree <- midpoint(tree)
  tree <- reorder(tree) #better reorder

  if(is.null(scale_x) & is.null(scale_y)){
    scale_x=max(tree$edge.length)*0.5
    scale_y=tree$Nnode+3
  }

  if(label==F){
    # display tree
    p <- ggtree(tree, size=0.3) +
      geom_tiplab(size=1) +
      geom_treescale(x=scale_x, y=scale_y, width=tree_scale_width, fontsize=2) +
      ggtitle(paste0(pre, ": taxa=", length(tree$tip.label), "; ", Sys.Date())) +
      geom_cladelabel(node=adjust_node, label="test", align=TRUE, angle=90, barsize=1, fontsize = 2, color='white', offset = offset) # this is used to help keep the tree in a narrow shape

  }else{
    tree$tip.label <- gsub("[-−]", "_", tree$tip.label)

    # separate group taxa
    label.info <- read_excel(info) %>% arrange(Group)
    label.info$name <- gsub("[-−]", "_", label.info$name)

    labels <- list()
    i=1
    for (i in 1:length(unique(label.info$Group))){
      data <- label.info %>% filter(Group==unique(label.info$Group)[i])
      labels[[unique(label.info$Group)[i]]] <- paste(data$name, sep=",")
    }

    # group taxa
    tree <- groupOTU(tree, labels)
    cols <- c("#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#666666", "blue", "red")

    p <- ggtree(tree, size=0.3) +
      geom_tiplab(aes(color=group), size=1) +
      scale_color_manual(name="Group", values=c("black", cols[1:length(labels)])) +
      geom_treescale(x=scale_x, y=scale_y, width=tree_scale_width, fontsize=2) +
      guides(color = guide_legend(order=1, ncol=1, override.aes = list(size = 2))) + #ncol=1
      theme(legend.position = "left", legend.text=element_text(size=5), legend.title=element_text(size=5)) +
      ggtitle(paste0(pre, ": taxa=", length(tree$tip.label), "; ", Sys.Date())) +
      geom_cladelabel(node=adjust_node, label="test", align=TRUE, angle=90, barsize=1, fontsize = 2, color='white', offset = offset) # this is used to help keep the tree in a narrow shape
  }

  if(treetype=="raxmltree"|treetype=="iqtree"){
    p <- p + geom_text2(aes(subset=!isTip&as.numeric(label)>min_support, label=label), color="#CC0099", size=1, hjust=1, vjust=1.1)

  }else{
    p <- p + geom_text2(aes(subset=!isTip&as.numeric(label)*100>min_support, label=round(as.numeric(label)*100,0)), color="#CC0099", size=1, hjust=1, vjust=1.1)
    }

  width = 6
  height = max(4*length(tree$tip.label)/60,3)

  print(p)
  ggsave(paste0(pre, "_taxa", length(tree$tip.label), ".", filetype), width=width, height=height, units="in", device=filetype, limitsize = FALSE)
  dev.off()


  # show node
  if (display_node==TRUE){
    p2 <- p + geom_text2(aes(subset=!isTip, label=node),color="red", size=1, hjust=1, vjust=-0.5) # add node number

    print(p2)
    ggsave(paste0(pre, "_taxa", length(tree$tip.label), ".", filetype), width=width, height=height, units="in", device=filetype, limitsize = FALSE)
    dev.off()

  }
#  return(tree)
}


