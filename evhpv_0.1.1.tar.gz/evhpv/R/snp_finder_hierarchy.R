#' Find exclusive SNP for lineages/sublineages;
#' @name snp_finder_hierarchy
#' @description  Find marker SNP for phylogeny groups;
#' @param alignment sequence alignment in fasta format;
#' @param lineage_info sequence plylogeny group information in csv format, should contain at least two columns named as "name" and "levelx", hierarchy example: "level1">"level2";
#' @param gap_ratio ratio of gaps allowed in the alignment column, default is 0.1;
#' @param conserved_ratio ratio to exclude conserved nucleotide position for the whole dataset, default is 0.9.
#' @param snp_ratio ratio to identify an nucleotide as a unique and conserved SNP in a lineage/group, default is 0.95.
#' @param ref name of refererence sequence;
#' @param out_dir output directory, defult is current working directory;
#' @return csv files showing SNP information and a fasta file containing the reference sequence;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 31 July 2019. Contact:ouzhihua@genomics.cn



#lineage_info="../tree/hpv18_lineage_test.csv"
#alignment="../alignment/hpv18_upto20190725_0.95len_trim_noN_uni.fasta"
#gap_ratio=0.1
#conserved_ratio = 0.98
#snp_ratio=0.95
#ref="AY262282_HPV18_na_na_refA1"
#out_dir=getwd()

snp_finder_hierarchy <- function(lineage_info, alignment, gap_ratio=0.1, conserved_ratio=0.98, snp_ratio=0.95, ref, out_dir=getwd()){
  library(Biostrings)
  library(dplyr)
  library(tidyr)

  filename <- paste0(out_dir, "/", gsub(".csv", "", gsub("^.*/", "", lineage_info)))
  # input consensu sequences
  fas <- readDNAStringSet(alignment)
  name = names(fas)
  seq = toupper(paste(fas))
  length = width(paste(fas))
  df <- data.frame(name, seq, length)

  # check if sequences are aligned
  if (length(unique(df$length))>1){
    print("Oops~ Sequences are not aligned!")
  }else{
    print("Nice! Sequences are properly aligned~")
  }


  # read lineage information
  dat_lineage <- read.csv(lineage_info, header=T, na.strings=c("", NA), stringsAsFactors = F)

  df_check <- semi_join(df, dat_lineage, by="name")
    # in case of old version of seq name, eg. 18|accession|place|time

  if(length(df_check$name)!=1){
    df$name <- gsub("\\|", "_", df$name)
  }

  # get alignment length and output ref
  ali_len <- df$length[df$name==ref]

  #output ref seq
  ref_out <- df %>% filter(name==ref) %>%
    mutate(fas = paste0(">", name, "\n", seq))
  write.table(ref_out$fas, paste0(filename, "_snp_ref.fasta"), sep="", col.name=F, row.names = F, quote=F)

  # match ali_position to real_position with ref
  position_match <- df %>% filter(name==ref) %>%
    select(name) %>% mutate(ali_position=NA, real_position=NA)
  position_match[2:ali_len, ] <- NA
  position_match$name <- ref
  refseq <- df %>% filter(name==ref)
  refseq <- refseq$seq[1]
  r <- 0
  for (i in 1:ali_len){
    position_match$ali_position[i] <- i
    if(substr(refseq, i, i) != "-"){
      r <- r+1
      position_match$real_position[i] <- r
    }else{
      position_match$real_position[i] <- paste0(r,"+gap")
    }
  }
  colnames(position_match)[1] <- "ref"

  # get levels
  n_levels <- sum(grepl("level", colnames(dat_lineage)))

  snp_hierarchy_strict <- data.frame(ref, ali_position=NA, real_position=NA, lineage=NA, Nucleotide=NA, Nucleotide_ratio=NA, nseq=NA, Freq=NA)

  for (l in 1:n_levels){
    # group and find lineages
    mylevel <- grep("level", colnames(dat_lineage), value=T)[l]
    dat_lineage_select <- dat_lineage %>% select(name, mylevel)
    colnames(dat_lineage_select) <- c("name", "lineage")
    dat_lineage_select <- dat_lineage_select %>% filter(!is.na(lineage))

    df_lin <- left_join(df, dat_lineage_select, by="name") %>% filter(!is.na(lineage))

    lineage_count <- df_lin %>% group_by(lineage) %>% count()

    df_lin <- left_join(df_lin, lineage_count, by="lineage") %>%
      mutate(lineage=paste0(mylevel, "_", lineage, "_n", n)) %>%
      select(-n)

    #write.csv(lineage_count, paste0(filename, "_", mylevel, "_count.csv"), row.names = F)


    # retrieve infomative sites
    #i=50

    gap_exclude <- vector()
    info_site <- vector()
    conserved_site <- vector()

    for (i in 1:ali_len){
      dfx <- vector()
      for (j in 1:length(df$name)){
        dfx <- c(dfx, substr(df$seq[j], i, i))
      }

      # exclude sites with too map gaps, gap_ratio can be used to control gap ratio in alignments.
      # keep usable site and if one nucleotide is dominate among all the sequences, then this site will not keep.
      dgap <- as.data.frame(table(dfx)) %>% filter(dfx == "-")

      if (length(dgap$Freq)>0 & dgap$Freq[1] > length(df$name)*gap_ratio){
        gap_exclude <- c(gap_exclude, i)
      }else{
        dx <- as.data.frame(table(dfx))
        if (max(dx$Freq)/sum(dx$Freq) < conserved_ratio){
          info_site <- c(info_site, i)
        }else{
          conserved_site <- c(conserved_site, i)
        }

      }
    }

    # get lineage marker SNP
    lineages <- unique(df_lin$lineage)
    snp <- data.frame(lineage=NA, ali_position=NA, Nucleotide=NA, Nucleotide_ratio=NA, nseq=NA, Freq=NA)


    for (i in 1:length(lineages)){
      # separate lineage
      data <- df_lin %>% filter(lineage==lineages[i]) %>% select(lineage, seq)

      # check info_site for respective lineage

      for (j in 1:length(info_site)){
        snpx <- vector()

        for (k in 1:length(data$lineage)){
          snpx <- c(snpx, substr(data$seq[k], info_site[j], info_site[j]))
        }


        snpl <- as.data.frame(table(snpx))
        colnames(snpl) <- c("Nucleotide", "Freq")
        snpl <- snpl %>% mutate(lineage=lineages[i],
                                ali_position=info_site[j],
                                nseq=length(data$lineage),
                                Nucleotide_ratio=format(round(Freq/nseq,3),3))
        snp <- rbind(snp, snpl) %>% na.omit()

        # keep ali_position that show conserved snp
      }
    }


    # spread snp
    snp_wide <- snp %>% na.omit() %>%
      arrange(desc(Nucleotide_ratio)) %>% distinct(lineage, ali_position, .keep_all=T) %>%
      select(lineage, Nucleotide, ali_position) %>%
      spread(lineage, Nucleotide)

    # normally snp should be exclusive for a certain lineage
    ali_position_exclude_strict <- vector()

    for (i in 1:length(snp_wide$ali_position)){
      nts <- as.character(snp_wide[i, 2:length(colnames(snp_wide))])

      #strict exclusion
      if (length(unique(nts)) < length(nts)){
        ali_position_exclude_strict <- c(ali_position_exclude_strict, snp_wide$ali_position[i])
      }

    }


    # use snp ratio to exclude those snp with low conservation
    snp <- snp %>% filter(!ali_position %in% ali_position_exclude_strict)
    ali_position_exclude2 <- snp %>% arrange(desc(Nucleotide_ratio)) %>%
      distinct(lineage, ali_position, .keep_all=T) %>%
      filter(Nucleotide_ratio < snp_ratio | grepl("-", Nucleotide)==1) %>%
      select(ali_position) %>% unique()

    snp <- snp %>% filter(!ali_position %in% ali_position_exclude2$ali_position)

    # match to ref real position
    snp <- left_join(snp, position_match, by="ali_position")

    log <- paste0(length(unique(snp$ali_position))," exclusive SNP found for ", lineage_info, " ", mylevel, " ", paste0(unique(snp$lineage), collapse = " "))
    print(log)
    write.table(log, paste0(gsub(".csv", "", lineage_info), "_log.txt"), col.names=F, row.names=F, quote=F, append=T)
    snp_hierarchy_strict <- rbind(snp_hierarchy_strict, snp)

  }

  snp_hierarchy_strict <- snp_hierarchy_strict %>% na.omit() %>%
    select(-ali_position) %>%
    arrange(desc(Nucleotide_ratio)) %>%
    distinct(lineage, real_position, .keep_all=T)

  if(length(snp_hierarchy_strict$real_position)>0){
    snp_hierarchy_strict_wide <- snp_hierarchy_strict %>%
     # mutate(Nuc_ratio=paste0(Nucleotide, "(", Nucleotide_ratio, ")")) %>%
      select(ref, lineage, Nucleotide, real_position) %>%
      spread(real_position, Nucleotide)

    write.csv(snp_hierarchy_strict_wide, paste0(filename, "_hierarchy_snp_wide_exclusive_", length(snp_hierarchy_strict_wide$ali_position), "_sites.csv"), row.names = F, na="")
    write.csv(snp_hierarchy_strict, paste0(filename, "_hierarchy_snp_ratio_exclusive.csv"), row.names = F, na="")
  }

}


