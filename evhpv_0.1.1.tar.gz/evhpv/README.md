The evhpv package supports the following analytical procedure:
    1. Genbank information processing;
    2. Fasta sequence processing: rename/extraction/deduplication/re-orientation...;
    3. Phylogeny reconstruction with iqtree;
    4. Phylogeny visualization for mega/raxml/iqtree with newick file and metadata; 
    5. Genetic distance calculation (pair-wise, intragroup, intergroup) for sequences;
    6. Lineage/sublineage definitions for sequences based on phylogeny and/or genetic distances;
    7. SNP finder for custom genetic classification, and reversely, identify genetic group based on marker SNPs
    ...

The evhpv package was created by Ou Zhihua. Contact: gina07662011@hotmail.com
09 May 2019







Usage of evhpv package

#-----------------------------install requirements when use R for the first time-----------------------
#download R: https://cran.r-project.org/bin/windows/base/
#download Rstudio: https://www.rstudio.com/products/rstudio/download2/#download

# install dependencies
install.packages("dplyr")
install.packages("stringr")
install.packages("ggplot2")
install.packages("tidyr")
install.packages("phangorn")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("Biostrings")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("ggtree")


#------------------------------run this to install evhpv----------------------------
# remove.packages("evhpv") #run this when you re-install evhpv

install.packages(file.choose(), repos = NULL, type="source") #choose location for "evhpv_0.x.x.tar.gz' when window pop out.


# run this to check if the package functions normally
?load_dependency()

#if evhpv help document can not show, run the following command:
.rs.restartR()


#run your command to analysis data.










Major update log for evhpv package
2020-02-28
move evhpv package scripts to a new package named "seqphy".

2019-08-20
add new functions: 
fasta_dis: calculate sequence pairwise dissimilarity, please make sure your sequences are properly aligned.


2019-08-20
add new functions: 
fasta_reader: read fasta sequence to dataframe, just for convenience.


2019-08-14
add new functions: 
snp_finder: identify exclusive and non-exclusive marker SNPs to distinguish user-defined lineages;
snp_finder_hierarchy: identify exclusive marker SNPs to distinguish custom lineages following a hierarchical system;
snp_matcher: identify lineages based on a marker SNP database and a fasta alignment.

improvement on other function:
gb_parse: function to sort HPV sequence information downloaded from NCBI;
fasta_extract_and_rename: extract and rename sequences downloaded from NCBI for downstream analysis;
fasta_unique: keep only unique sequences;
fasta_unique_hpvpro (temp function): keep only unique sequences for each group (NCBI/BGI/ref);
fasta_reduce: remove highly similar sequences based on custom difference threshold.


2019-06-19
add new functions:
fasta_len_filter: generate sequence length data and output info for sequence with a length over a custom threshold;


2019-06-19
add new functions:
generate_rep_tree: generate a newick file based on an inter-group genetic distance matrix


2019-06-12
add new functions:
dis_inter_group: calculate mean inter-group genetic distances;
dis_inter_group_median (not finished): calculate median inter-group genetic distances;


2019-06-02
add new functions:
gene_frame: ddjust CDS to the right reading frame so that the sequence could be translated to protein sequence;
ncr_remove: exclude non-coding regions between E5 and L2 for hpv genomes;


2019-05-19
add new functions:
display_tree_with_metadata (renamed as tree_display_with_metadata): display phylogeny for iqtree/mega/raxml trees along with metadata;


2019-05-17
add new functions:
gene_extract: extract CDS from sequnece alignment based on reference CDS index;
gene_extract_shortenHPV18 (temporary function): extract CDS from shortened HPV18 sequnece alignment based on reference CDS index;
gene_cat: concatenate CDS to make pseudo-genomes.
reopen_hpv18(temp function): adjust the coordinate of HPV18 genomes, since in the HPV processing procedure, the first 6nt are moved to the end. This needs to be corrected.
sh_iqtree: generate iqtree work.sh, allocating CPU and thread usage automatically based on sizes of alignments;
check_alignment(temp function): preserve sequences with a length over a defined ratio of genomic full length. 

add information files:
HPV_CDS.txt



2019-05-16
add new functions:
dis_hist: calculate pair-wise genetic distances and generate genetic histograms;


2019-05-12
add new functions:
display_tree (renamed as tree_display): display phylogeny for iqtree/mega/raxml trees;
lineage_output: allow output sublineage info for each taxa;
load_dependency: load all packages reqired for the normal function of evhpv package;


2019-05-09
add basic function to show iqtree phylogeny and check sublineages based on phylogeny and sequences.
seq_distance: calculate pair-wise distance  with pairwise deletion between ref and other taxa, output will be used for lineage/sublineage definition. (renamed as lineage_dis on 2019-08-15)
lineage_output: output lineage difinition info and phylogeny for taxa;

