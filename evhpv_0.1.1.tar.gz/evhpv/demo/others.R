# remove duplicates of full genomes
rm(list=ls())
library(evhpv)

setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/ori_data")

files <- list.files(path=".", pattern="hpv18_ncbi_bgi_uptozhu20190401_trim.fasta")
for (i in 1:length(files)){
  alignment <- files[i]
  unique_seq(myseq=alignment, min_len=7070)
}




# extract CDS
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190528_phy20190528")

extract_gene(alignment="hpv16_ncbi_bgi_uptozhu20190401_trim_uni.fasta",
             pre="HPV16", hpvtype=16,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))

extract_gene(alignment="hpv52_ncbi_bgi_uptozhu20190401_trim_uni.fasta",
             pre="HPV52", hpvtype=52,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))

extract_gene(alignment="hpv58_ncbi_bgi_uptozhu20190401_trim_uni.fasta",
             pre="HPV58", hpvtype=58,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))

#extract_gene_shortenHPV18(alignment="hpv18_ncbi_bgi_uptozhu20190401_trim_uni.fasta",
extract_gene(alignment="hpv18_ncbi_bgi_uptozhu20190401_trim_uni.fasta",
                          pre="HPV18", hpvtype=18,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))







# check alignment
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/hpv18_cds")

files <- list.files(path=".", pattern=".fasta")
for (i in 1:length(files)){
  alignment <- files[i]
  check_alignment(alignment=alignment, ratio=0.7)
}




# cat sequences
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/hpv18_cds")

files <- list.files(path=".", pattern="HPV16")
cat_gene(files=files, pre="HPV16")

files <- list.files(path=".", pattern="selected.fasta")
cat_gene(files=files, pre="HPV18")

files <- list.files(path=".", pattern="HPV52")
cat_gene(files=files, pre="HPV52")

files <- list.files(path=".", pattern="HPV58")
cat_gene(files=files, pre="HPV58")


# remove duplicates
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/hpv18_cds")

files <- list.files(path=".", pattern="_cat.fasta")
for (i in 1:length(files)){
  alignment <- files[i]
  unique_seq(myseq=alignment, min_len=100)
}


# remove highly similar sequences
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/hpv18_cds")

files <- list.files(path=".", pattern="_cat_uni.fasta")
for (i in 1:length(files)){
  alignment <- files[i]
  reduce_seq(myseq=alignment, ndiff=3)
}


# extract the corresponding full genomes based on accession number of the valid cat-genomes
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/hpv18_cds")
extract_seq(fas="../hpv16_ncbi_bgi_uptozhu20190401_trim_uni.fasta", index="HPV16_cat_ndif3.fasta")
extract_seq(fas="../ori_data/hpv18_ncbi_bgi_uptozhu20190401_trim_uni.fasta", index="HPV18_cat_ndif3.fasta")
extract_seq(fas="../hpv52_ncbi_bgi_uptozhu20190401_trim_uni.fasta", index="HPV52_cat_ndif3.fasta")
extract_seq(fas="../hpv58_ncbi_bgi_uptozhu20190401_trim_uni.fasta", index="HPV58_cat_ndif3.fasta")




# re-extract CDS
# open in BioEdit and maunuall check if AA Frame is normal!!
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190606_phy20190606/hpv18_cds")

extract_gene(alignment="hpv16_ncbi_bgi_uptozhu20190401_trim_uni_extract.fasta",
             pre="HPV16", hpvtype=16,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))

extract_gene(alignment="hpv52_ncbi_bgi_uptozhu20190401_trim_uni_extract.fasta",
             pre="HPV52", hpvtype=52,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))

extract_gene(alignment="hpv58_ncbi_bgi_uptozhu20190401_trim_uni_extract.fasta",
             pre="HPV58", hpvtype=58,
             genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))

#extract_gene_shortenHPV18(alignment="hpv18_ncbi_bgi_uptozhu20190401_trim_uni_extract.fasta",
extract_gene(alignment="hpv18_ncbi_bgi_uptozhu20190401_trim_uni_extract.fasta",
                          pre="HPV18", hpvtype=18,
                          genes=c("E6", "E7", "E1", "E2", "E4", "E5", "L2", "L1"))





# cat E1 E2 L1 L2 sequences

rm(list=ls())
library(evhpv)

files <- c("HPV16_E1.fasta", "HPV16_E2.fasta", "HPV16_L1.fasta", "HPV16_L2.fasta")
cat_gene(files=files, pre="HPV16_E1E2L1L2")

files <- c("HPV18_E1.fasta", "HPV18_E2.fasta", "HPV18_L1.fasta", "HPV18_L2.fasta")
cat_gene(files=files, pre="HPV18_E1E2L1L2")

files <- c("HPV52_E1.fasta", "HPV52_E2.fasta", "HPV52_L1.fasta", "HPV52_L2.fasta")
cat_gene(files=files, pre="HPV52_E1E2L1L2")

files <- c("HPV58_E1.fasta", "HPV58_E2.fasta", "HPV58_L1.fasta", "HPV58_L2.fasta")
cat_gene(files=files, pre="HPV58_E1E2L1L2")



#generate iqtree work script --- check best model and build tree
rm(list=ls())
library(evhpv)

files <- list.files(pattern=".fasta")

for (i in 1:length(files)){
  sh_iqtree(alignment=files[i],
            input_dir="/hwfssz5/ST_INFECTION/HPV/ouzhihua/phylogeny/phy20190606/phy_alignments",
            output_dir="/hwfssz5/ST_INFECTION/HPV/ouzhihua/phylogeny/phy20190606/bestmodel",
            model="TEST")
}




#generate iqtree work script --- use model GTR+F+I+G4 to build tree
rm(list=ls())
library(evhpv)
files <- list.files(pattern=".fasta")

for (i in 1:length(files)){
  sh_iqtree(alignment=files[i],
            input_dir="/hwfssz5/ST_INFECTION/HPV/ouzhihua/phylogeny/phy20190606/phy_alignments",
            output_dir="/hwfssz5/ST_INFECTION/HPV/ouzhihua/phylogeny/phy20190606/GTRtree",
            model="GTR+F+I+G4")
}





# define sublineages
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190528_phy20190528")
iqtree <- display_tree(treefile = "hpv16_fg.fasta.treefile", treetype = "iqtree", min_support=70, pre="hpv16_fg")
iqtree <- display_tree(treefile = "hpv18_fg.fasta.treefile", treetype = "iqtree", min_support=70, pre="hpv18_fg")
iqtree <- display_tree(treefile = "hpv52_fg.fasta.treefile", treetype = "iqtree", min_support=70, pre="hpv52_fg")
iqtree <- display_tree(treefile = "hpv58_fg.fasta.treefile", treetype = "iqtree", min_support=70, pre="hpv58_fg")


# calculate inter-group genetic distances
dist_inter_group(myfasta=myfasta, mylineage=mylineage, model=model)




# plot genetic distance histogram
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190528_phy20190528/dencr")
files <- list.files(path=".", pattern=".fasta$")

for (i in 1:length(files)){
  pre <- gsub("\\.fasta", "", files[i])
  # pre <- paste0("distance_histogram/", gsub("\\.fasta", "", files[i]))
  myfasta <- files[i]
  model="TN93"
  dis_hist(pre=pre, myfasta=myfasta, model=model)
}







# check cds
rm(list=ls())
library(evhpv)
setwd("~/Documents/BGI/Worklog/o20190513_bootstrap_comparison/CDS/raw_CDS")

files <- list.files(path=".", pattern="_selected.fasta")
for (i in 1:length(files)){
  alignment <- files[i]
  adjust_cds(alignment=alignment)
}


