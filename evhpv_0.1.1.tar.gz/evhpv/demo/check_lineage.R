#example file for checking hpv18 sublineage with evhpv package.

library(evhpv)


iqtree <- system.file("extdata/hpv18.treefile", package = "evhpv")
alignment <- system.file("extdata/hpv18.fasta", package = "evhpv")
minUFB <- 70
outname <- "hpv18_lineage"

##
load_dependency()
tree <- display_tree(treefile=iqtree, treetype="iqtree", min_support=minUFB, pre=outname)
dis <- seq_distance(alignment= alignment, outname=outname)

# ------------------------ please manually check the tree!!






# get sublineage cluster based on topology and boostrap support
hpvtype <- "HPV18"
min_dis <- 0.009

A1_node <- get.offspring.tip(tree,node=162)
A2_node <- get.offspring.tip(tree,node=244)
A3_node <- get.offspring.tip(tree,node=206)
A4_node <- get.offspring.tip(tree,node=194)
A5_node <- get.offspring.tip(tree,node=191)
B1_node <- get.offspring.tip(tree,node=170)
B2_node <- get.offspring.tip(tree,node=184)
B3_node <- get.offspring.tip(tree,node=187)
C_node <- get.offspring.tip(tree,node=190)


df <- dis %>% mutate(lineage=ifelse(A1 < min_dis & taxa %in% A1_node, "A1",
                                    ifelse(A2 < min_dis & taxa %in% A2_node, "A2",
                                           ifelse(A3 < min_dis & taxa %in% A3_node, "A3",
                                                  ifelse(A4 < min_dis & taxa %in% A4_node, "A4",
                                                         ifelse(A5 < min_dis & taxa %in% A5_node, "A5",
                                                                ifelse(B1 < min_dis & taxa %in% B1_node, "B1",
                                                                       ifelse(B2 < min_dis & taxa %in% B2_node, "B2",
                                                                              ifelse(B3 < min_dis & taxa %in% B3_node, "B3",
                                                                                     ifelse(C < min_dis & taxa %in% C_node, "C", "undetermined"))))))))))



lineage_output(iqtree=iqtree, UFBthreshold=minUFB, distance=df, hpvtype=hpvtype, outname=outname)
