
#-----------------------------install requirements when use R for the first time-----------------------
#download R: https://cran.r-project.org/bin/windows/base/
#download Rstudio: https://www.rstudio.com/products/rstudio/download2/#download

# install dependencies
install.packages("dplyr")
install.packages("stringr")
install.packages("ggplot2")
install.packages("tidyr")
install.packages("phangorn")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("Biostrings")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("ggtree")


#------------------------------run when you re-install evhpv------------------------
remove.packages("evhpv") #run this





#------------------------------run this to install evhpv----------------------------
install.packages(file.choose(), repos = NULL, type="source") #choose location for "evhpv_0.1.0.tar.gz' when window pop out.

#install.packages("pathto/evhpv_0.1.0.tar.gz", repos = NULL, type="source") #choose location for "evhpv_0.1.0.tar.gz' when window pop out.


# run this to check if the package functions normally
?display_tree()

#if evhpv help document can not show, run the following command:
.rs.restartR()


#------------------------------run your command to analysis data------------------------------
